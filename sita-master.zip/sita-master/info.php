<?php
include("layout.php"); 
?>
<div class="container"><br><br>
    <div class="panel panel-default" >
		<!-- Default panel contents -->
	    <div class="panel-heading">Project Summary</div>
	    <div class="panel-body">
	    	<p>
	    		The project will be a simple online order tracking system. Visitors will visit product page. If anyone choose a product to purchase he needs to sign up and become a customer. After becoming a customer system allows him to login and order products. Customer can see his own order status anytime. <br><br>
	    		Admin user can view and update order status. After processing an order admin user changes the order status so that customer can see that his order has been processed. Order processing can be performed outside the system.  <br><br>
	    		Admin user can add, change or delete products
	    	</p>
	    </div>
	</div>
</div>
