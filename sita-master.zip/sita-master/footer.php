<style type="text/css">
	html, body {
    	height: 100%;
    }
	.footer {
	    position: fixed;
	    left: 0px;
	    bottom: 0px;
	    height: 35px;
	    width: 100%;
	    
	}
	
</style>

<div style="text-align: center" class="footer panel-footer">Copyright &#169; <?php echo date("Y"); ?> Shah Mohammad Mostakim. All rights reserved.</div>